const fetchChatGPT = async (message) => {
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.REACT_APP_OPENAI_API_KEY}`,
    };

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({
                model: 'gpt-4',
                messages: [{ role: 'user', content: message }],
            }),
        });
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching ChatGPT response:', error);
        throw error;
    }
};

export default fetchChatGPT;
