from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Get the API key
api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    raise ValueError("API key not found. Please add it to your .env file.")

print(f"API Key Loaded: {api_key[:10]}...")  # Display first 10 characters for confirmation
