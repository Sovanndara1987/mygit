const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const redisAdapter = require('socket.io-redis');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Use Redis adapter for scalability
io.adapter(redisAdapter({ host: 'localhost', port: 6379 }));

// Serve static files
app.use(express.static('public'));

// WebSocket communication
io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('message', (msg) => {
        console.log(`Message received: ${msg}`);
        socket.emit('response', `Server says: ${msg}`);
    });

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

// Periodic live updates
setInterval(() => {
    const currentTime = new Date().toLocaleTimeString();
    io.emit('live-update', `Current time: ${currentTime}`);
}, 5000);

// Start server
server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
